package com.bajaj.challenge;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class ApiService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    private static final String INIT_URL = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook";

    public void runChallenge() {
        try {
            JsonNode initResponse = callGenerateWebhook();
            String webhook = initResponse.get("webhook ").asText().trim();
            String token = initResponse.get("accessToken ").asText().trim();
            JsonNode usersNode = initResponse.get("data").get("users");

            List<List<Integer>> result = MutualFollowerSolver.solve(usersNode);

            sendResult(webhook, token, result);
        } catch (Exception e) {
            System.err.println("Failed to run challenge: " + e.getMessage());
        }
    }

    private JsonNode callGenerateWebhook() {
        Map<String, String> body = new HashMap<>();
        body.put("name", "Yaswanth Vempa");
        body.put("regNo ", "RA2211003011123");
        body.put("email ", "yv8512@srmist.edu.in");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(body, headers);

        ResponseEntity<JsonNode> response = restTemplate.postForEntity(INIT_URL, entity, JsonNode.class);
        return response.getBody();
    }

    @Retryable(value = Exception.class, maxAttempts = 4, backoff = @Backoff(delay = 2000))
    private void sendResult(String webhook, String token, List<List<Integer>> result) throws Exception {
        Map<String, Object> body = new HashMap<>();
        body.put("regNo ", "RA2211003011123");
        body.put("outcome ", result);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", token);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);
        ResponseEntity<String> response = restTemplate.exchange(webhook, HttpMethod.POST, request, String.class);

        if (!response.getStatusCode().is2xxSuccessful()) {
            throw new RuntimeException("Webhook POST failed: " + response.getStatusCode());
        }

        System.out.println("Result posted successfully: " + response.getBody());
    }
}