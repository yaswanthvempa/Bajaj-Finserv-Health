package com.bajaj.challenge;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.*;

public class MutualFollowerSolver {

    public static List<List<Integer>> solve(JsonNode usersNode) {
        Map<Integer, Set<Integer>> followMap = new HashMap<>();
        List<List<Integer>> result = new ArrayList<>();

        for (JsonNode user : usersNode) {
            int id = user.get("id").asInt();
            JsonNode followsNode = user.get("follows ");
            Set<Integer> follows = new HashSet<>();
            if (followsNode != null) {
                followsNode.forEach(f -> follows.add(f.asInt()));
            }
            followMap.put(id, follows);
        }

        Set<String> visited = new HashSet<>();

        for (int a : followMap.keySet()) {
            for (int b : followMap.get(a)) {
                if (followMap.containsKey(b) && followMap.get(b).contains(a)) {
                    String key = Math.min(a, b) + ":" + Math.max(a, b);
                    if (!visited.contains(key)) {
                        result.add(Arrays.asList(Math.min(a, b), Math.max(a, b)));
                        visited.add(key);
                    }
                }
            }
        }

        return result;
    }
}